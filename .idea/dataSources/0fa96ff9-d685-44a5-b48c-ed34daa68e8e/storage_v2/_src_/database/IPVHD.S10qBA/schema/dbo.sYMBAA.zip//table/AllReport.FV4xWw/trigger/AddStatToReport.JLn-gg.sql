-- =============================================
-- Author:		<VMS>
-- Create date: <14.11.2018>
-- Description:	<Добавляет в таблицу строки отчета со всеми статьями >
-- =============================================
CREATE TRIGGER [dbo].[AddStatToReport]
   ON  [dbo].[AllReport]
   AFTER INSERT
AS 
BEGIN

	SET NOCOUNT ON;

	DECLARE @TabName Varchar(20)
	DECLARE @IDStat Int

	SELECT @TabName = Tbl FROM Report WHERE ID = (SELECT IDReport FROM inserted)
	
	DECLARE StatCursor CURSOR FOR
	SELECT Stat.ID FROM inserted 
		INNER JOIN StatToReport ON StatToReport.IDreport = inserted.IDreport
		INNER JOIN Stat ON Stat.ID = StatToReport.IDstat

	OPEN StatCursor
		FETCH NEXT FROM StatCursor INTO @IDStat
		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @TabName = 'Ej'
			BEGIN
			INSERT INTO Ej(IDStat, IDreportAll) VALUES (@IDStat, (SELECT ID FROM inserted))
			END
			IF @TabName = 'Prih'
			BEGIN
			INSERT INTO Prih(IDStat, IDreportAll) VALUES (@IDStat, (SELECT ID FROM inserted))
			END
			IF @TabName = 'Nach'
			BEGIN
			INSERT INTO Nach(IDStat, IDallReport) VALUES (@IDStat, (SELECT ID FROM inserted))
			END
			IF @TabName = 'Kass'
			BEGIN
			INSERT INTO Kass(IDStat, IDallReport) VALUES (@IDStat, (SELECT ID FROM inserted))
			END
			IF @TabName = 'DtKt'
			BEGIN
			INSERT INTO DtKt(IDStat, IDallReport) VALUES (@IDStat, (SELECT ID FROM inserted))
			END
			FETCH NEXT FROM StatCursor INTO @IDStat
		END
	CLOSE StatCursor;
	DEALLOCATE StatCursor;
END
GO

