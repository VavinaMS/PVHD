-- =============================================
-- Author:		<VMS>
-- Create date: <26.11.2018>
-- Description:	<Заполнение расчетных полей отчета>
-- =============================================
CREATE TRIGGER [dbo].[calcKt]
   ON  [dbo].[Ej]
   AFTER UPDATE
AS 
BEGIN

	SET NOCOUNT ON;

    update Ej set Kt_end = (SELECT Kt_Start FROM inserted) + (SELECT vistavleno FROM inserted) - (SELECT Oplacheno FROM inserted) where id = (SELECT id FROM inserted)


	DECLARE @IDStat Int
	DECLARE @IDreport Int
	SELECT @IDStat = IDstat, @IDreport = IDreportAll FROM inserted
	IF @IDStat = 9 or @IDStat = 11 or @IDStat = 13 or @IDStat = 15 or @IDStat = 16 
	BEGIN
		update Ej set Kt_Start = (SELECT sum(Kt_Start) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
	    update Ej set Kt_end = (SELECT sum(Kt_end) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
		update Ej set Oplacheno = (SELECT sum(Oplacheno) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
		update Ej set vistavleno = (SELECT sum(vistavleno) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
		update Ej set prosroch_end = (SELECT sum(prosroch_end) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
		update Ej set prosroch_Start = (SELECT sum(prosroch_Start) FROM Ej WHERE (IDstat = 11 or IDstat = 13 or IDstat = 9 or IDstat = 15 or IDstat = 16) and IDreportAll = @IDreport)
								 where IDstat = 8 and IDreportAll = @IDreport
	END

	IF @IDStat = 23 or @IDStat = 24 or @IDStat = 25 or @IDStat = 26 or @IDStat = 27 
	BEGIN
		update Ej set Kt_Start = (SELECT sum(Kt_Start) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
	    update Ej set Kt_end = (SELECT sum(Kt_end) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
		update Ej set Oplacheno = (SELECT sum(Oplacheno) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
		update Ej set vistavleno = (SELECT sum(vistavleno) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
		update Ej set prosroch_end = (SELECT sum(prosroch_end) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
		update Ej set prosroch_Start = (SELECT sum(prosroch_Start) FROM Ej WHERE (IDstat = 23 or IDstat = 24 or IDstat = 25 or IDstat = 26 or IDstat = 27) and IDreportAll = @IDreport)
								 where IDstat = 22 and IDreportAll = @IDreport
	END

	IF @IDStat = 30 or @IDStat = 31 or @IDStat = 32 or @IDStat = 33 or @IDStat = 34 or @IDStat = 35 or @IDStat = 36 or @IDStat = 37
	BEGIN
		update Ej set Kt_Start = (SELECT sum(Kt_Start) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
	    update Ej set Kt_end = (SELECT sum(Kt_end) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
		update Ej set Oplacheno = (SELECT sum(Oplacheno) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
		update Ej set vistavleno = (SELECT sum(vistavleno) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
		update Ej set prosroch_end = (SELECT sum(prosroch_end) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
		update Ej set prosroch_Start = (SELECT sum(prosroch_Start) FROM Ej WHERE (IDStat = 30 or IDStat = 31 or IDStat = 32 or IDStat = 33 or IDStat = 34 or IDStat = 35 or IDStat = 36 or IDStat = 37) and IDreportAll = @IDreport)
								 where IDstat = 29 and IDreportAll = @IDreport
	END


END
GO

