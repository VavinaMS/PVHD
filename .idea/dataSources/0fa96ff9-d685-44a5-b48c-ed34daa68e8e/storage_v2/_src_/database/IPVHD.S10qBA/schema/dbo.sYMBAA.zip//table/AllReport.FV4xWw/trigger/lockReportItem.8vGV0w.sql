-- =============================================
-- Author:		<VMS>
-- Create date: <26.11.2018>
-- Description:	<Блокирует изменение уже проверенного отчета>
-- =============================================
CREATE TRIGGER [dbo].[lockReportItem]
   ON  [dbo].[AllReport]
   AFTER UPDATE
AS 
BEGIN
	-- SET NOCOUNT ON added to prevent extra result sets from
	-- interfering with SELECT statements.
	SET NOCOUNT ON;

    DECLARE @TabName Varchar(20)
	SELECT @TabName = Tbl FROM Report WHERE ID = (SELECT IDReport FROM inserted)
	IF @TabName = 'Ej'
	BEGIN
		UPDATE Ej SET lock = (SELECT lock FROM inserted) WHERE IDreportAll = (SELECT id FROM inserted)
	END

END
GO

